function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6jQTYIFl17i":
        Script1();
        break;
      case "6WCAsHV1tN3":
        Script2();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
